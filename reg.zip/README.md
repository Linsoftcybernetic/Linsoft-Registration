# Linsoft-Registration
A registration form for our training course built with python
